import time
import oracledb
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager


class DatabaseConnection:
    def __init__(self, config):
        self.config = config
        self.engine = None
        self.Session = None
        self.max_retries = 5
        self.retry_delay = 5  # seconds
        self.pool = None

    def connect(self):
        retry_count = 0
        while retry_count < self.max_retries:
            try:
                # Initialize Oracle client
                # oracledb.init_oracle_client(
                #     lib_dir=r"ai_db.config.ini"
                # )
                oracledb.init_oracle_client()

                # Create connection pool
                self.pool = oracledb.create_pool(
                    user=self.config["user"],
                    password=self.config["password"],
                    dsn=self.config["dsn"],
                    min=int(self.config["min"]),
                    max=int(self.config["max"]),
                    increment=int(self.config["inc"]),
                )

                # Create SQLAlchemy engine using the pool
                self.engine = create_engine(
                    "oracle+oracledb://",
                    creator=self.pool.acquire,
                    pool_size=10,
                    max_overflow=20,
                )

                self.Session = sessionmaker(bind=self.engine)
                print("Database connection established successfully")
                return
            except (SQLAlchemyError, oracledb.Error) as e:
                print(f"Error connecting to database: {e}")
                retry_count += 1
                if retry_count < self.max_retries:
                    print(f"Retrying in {self.retry_delay} seconds...")
                    time.sleep(self.retry_delay)
                else:
                    print("Max retries reached. Unable to connect to the database.")
                    raise

    @contextmanager
    def get_session(self):
        if not self.Session:
            self.connect()
        session = self.Session()
        try:
            yield session
            session.commit()
        except:
            session.rollback()
            raise
        finally:
            session.close()


db_connection = None


def init_db(config):
    global db_connection
    db_connection = DatabaseConnection(config)
    db_connection.connect()
    return db_connection, db_connection.engine


def get_db_connection():
    global db_connection
    if not db_connection:
        raise Exception("Database connection not initialized")
    return db_connection